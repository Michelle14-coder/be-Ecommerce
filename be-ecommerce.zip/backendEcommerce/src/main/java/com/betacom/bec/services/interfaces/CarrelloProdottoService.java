package com.betacom.bec.services.interfaces;

public class CarrelloProdottoService {

}