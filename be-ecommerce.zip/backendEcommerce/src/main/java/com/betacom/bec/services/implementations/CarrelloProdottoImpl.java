package com.betacom.bec.services.implementations;


import org.springframework.stereotype.Service;



@Service
public class CarrelloProdottoImpl {


    
}